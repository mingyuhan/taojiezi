﻿## 一、UDP介绍
**Socket**
 1.套接字是支持TCP/IP协议的网络通信的基本操作单元。可以将套接字看作不同主机间的进程进行双向通信的端点，它构成了单个主机内及整个网络间的编程界面。
 2.套接字的工作原理：
通过互联网进行通信，至少需要一对套接字，其中一个运行于客户机端，称之为ClientSocket，另一个运行于服务器端，称之为ServerSocket。
套接字之间的连接过程可以分为三个步骤：服务器监听，客户端请求，连接确认。
**TCP**
TCP协议提供的是端到端服务。TCP协议所提供的端到端的服务是保证信息一定能够到达目的地址。它是一种面向连接的协议。
TCP编程的服务器端一般步骤
①创建一个socket，用函数socket()
②绑定IP地址、端口等信息到socket上，用函数bind()
③开启监听，用函数listen()
④接收客户端上来的连接，用函数accept()
⑤收发数据，用函数send()和recv()，或者read()和write()
⑥关闭网络连接；
⑦关闭监听；
TCP编程的客户端一般步骤
①创建一个socket，用函数socket()
②设置要连接的对方的IP地址和端口等属性
③连接服务器，用函数connect(）
④收发数据，用函数send()和recv()，或者read()和write()
⑤关闭网络连接
**UDP**
UDP协议提供了一种不同于TCP协议的端到端服务。UDP协议所提供的端到端传输服务是尽力而为(best-effort)的，即UDP套接字将尽可能地传送信息，但并不保证信息一定能成功到达目的地址，而且信息到达的顺序与其发送顺序不一定一致。
UDP编程的服务器端一般步骤
①创建一个socket，用函数socket()
②绑定IP地址、端口等信息到socket上，用函数bind()
③循环接收数据，用函数recvfrom()
④关闭网络连接
UDP编程的客户端一般步骤
①创建一个socket，用函数socket()
②设置对方的IP地址和端口等属性
③发送数据，用函数sendto()
④关闭网络连接
## 二、在命令行输出信息，用UDP套接字给其他电脑发送信息
1.新建项目，选择控制台应用程序，一个客户端，一个服务器端。
![在这里插入图片描述](https://img-blog.csdnimg.cn/109aac9744934e3da393acf3cc06a594.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
服务器代码：

```csharp
using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace UDP
{
    class Program
    {
        static void Main(string[] args)
        {
            int recv;
            byte[] data = new byte[1024];

            //得到本机IP，设置UDP端口号         
            IPEndPoint ip = new IPEndPoint(IPAddress.Any, 8001);
            Socket newsock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            //绑定网络地址并监听
            newsock.Bind(ip);

            Console.WriteLine("This is a Server, host name is {0}", Dns.GetHostName());

            //等待客户机连接
            Console.WriteLine("Waiting for a client");

            //得到客户机IP
            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
            EndPoint Remote = (EndPoint)(sender);
            recv = newsock.ReceiveFrom(data, ref Remote);
            Console.WriteLine("Message received from {0}: ", Remote.ToString());
            Console.WriteLine(Encoding.UTF8.GetString(data, 0, recv));

            //客户机连接成功后，发送信息
            string welcome = "你好 ! ";

            //字符串与字节数组相互转换
            data = Encoding.UTF8.GetBytes(welcome);

            //发送信息
            newsock.SendTo(data, data.Length, SocketFlags.None, Remote);
            while (true)
            {
                data = new byte[1024];
                //接收信息
                recv = newsock.ReceiveFrom(data, ref Remote);
                Console.WriteLine(Encoding.UTF8.GetString(data, 0, recv));
                //newsock.SendTo(data, recv, SocketFlags.None, Remote);
            }
        }

    }
}


```
客户端代码（需要更改ip地址）：

```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace UDPClient
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] data = new byte[1024];
            string input, stringData;

            //构建TCP 服务器
            Console.WriteLine("This is a Client, host name is {0}", Dns.GetHostName());

            //设置服务IP（这个IP地址是服务器的IP），设置TCP端口号
            IPEndPoint ip = new IPEndPoint(IPAddress.Parse("192.168.181.1"), 8001);

            //定义网络类型，数据连接类型和网络协议UDP
            Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            string welcome = "你好! ";
            data = Encoding.UTF8.GetBytes(welcome);
            server.SendTo(data, data.Length, SocketFlags.None, ip);
            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
            EndPoint Remote = (EndPoint)sender;

            data = new byte[1024];
            //对于不存在的IP地址，加入此行代码后，可以在指定时间内解除阻塞模式限制
            int recv = server.ReceiveFrom(data, ref Remote);
            Console.WriteLine("Message received from {0}: ", Remote.ToString());
            Console.WriteLine(Encoding.UTF8.GetString(data, 0, recv));
            int i = 0;
            while (true)
            {
                string s = "hello cqjtu!重交物联2019级" + i;
                Console.WriteLine(s);
                server.SendTo(Encoding.UTF8.GetBytes(s), Remote);
                if (i == 50)
                {
                    break;
                }
                i++;
            }
            Console.WriteLine("Stopping Client.");
            server.Close();
        }

    }
}


```
先开启服务器端再打开客户端
![在这里插入图片描述](https://img-blog.csdnimg.cn/290dfa3408584c96a36bfe24950c3b55.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
## 三、From窗口按下按钮发送信息
创建项目，选择窗体应用，也需要客户端和服务器端
![在这里插入图片描述](https://img-blog.csdnimg.cn/2f0f1829db204e56821d2428ec63768b.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
客户端：
从工具箱找到按钮和文本框
![在这里插入图片描述](https://img-blog.csdnimg.cn/5d7b6e9223b342bb84e9b59eb6a65bd1.png)
![在这里插入图片描述](https://img-blog.csdnimg.cn/a606ca28d11149719550869dc57571be.png)
勾选文本框里的MultiLine
![在这里插入图片描述](https://img-blog.csdnimg.cn/740eddbb92924f14be6052290faeb274.png)

![在这里插入图片描述](https://img-blog.csdnimg.cn/54eab0ade73942c38182a40511c38e42.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
客户端代码，需要更改namespace，ip
```csharp
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muti_thread_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Socket socketSend;
        private void button1_Click(object sender, EventArgs e)
        {
            
            socketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint point = new IPEndPoint(IPAddress.Parse("192.168.181.1"), 8001);
            socketSend.Connect(point);
            showMsg("连接成功!");
            Thread th = new Thread(Receive);
            th.IsBackground = true;
            th.Start();
        }
        //客户端接收服务器发送的消息
        void Receive()
        {
            try
            {
                while (true)
                {
                    byte[] buffer = new byte[1024 * 1024 * 2];
                    int r = socketSend.Receive(buffer);
                    if (r == 0)
                    {
                        break;
                    }
                    string str = Encoding.UTF8.GetString(buffer, 0, r);
                    Invoke(new Action(() => {//在线程里修改界面
                        showMsg(socketSend.RemoteEndPoint + ":" + str);
                    }));
                }
            }
            catch
            { }
        }
        void showMsg(string s)
        {
            textBox1.AppendText(s + "\r\n");
        }
        //客户端向服务器发送消息


        private void button2_Click(object sender, EventArgs e)
        {
            string str = textBox2.Text;
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(str);
            socketSend.Send(buffer);  
        }
    }
}


```
服务器：
![在这里插入图片描述](https://img-blog.csdnimg.cn/12333b8b427f4ca7aace39254e4e5f7f.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)

```csharp
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muti_thread_server
{
    public partial class Form1 : Form
    {
        string str="没有改变";
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //点击开始侦听的时候，服务器创建一个负责监听IP地址跟端口号的Socket
                Socket socketwatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Any;
                //创建端口对象
                IPEndPoint point = new IPEndPoint(ip, 8001);
                //绑定
                socketwatch.Bind(point);

                showMsg("监听成功！");
                socketwatch.Listen(10);
                //创建一个线程
                Thread th = new Thread(listen);
                th.IsBackground = true;
                th.Start(socketwatch);

            }
            catch
            {
                showMsg("监听失败");
            }

        }
        Socket socketSend;
        //等待客户端的连接
        void listen(Object o)
        {
            try
            {
                
                Socket socketwatch = o as Socket;
                int i = 0;
                while (true)
                {
                    //等待客户端的连接
                    socketSend = socketwatch.Accept();

                    str = socketSend.RemoteEndPoint.ToString() + ":" + "连接成功！";
                    Invoke(new Action(() => {//在线程里修改界面
                        showMsg(socketSend.RemoteEndPoint.ToString() + ":" + "连接成功！");
                    }));
                    Thread th = new Thread(Receive);
                    th.IsBackground = true;
                    th.Start(socketSend);
                }
            }
            catch
            {            }
        }
        //接收客户端发送的信息
        void Receive(Object o)
        {
            try
            {
                Socket socketSend = o as Socket;
                while (true)
                {
                    byte[] buffer = new byte[1024 * 1024 * 2];
                    int r = socketSend.Receive(buffer);
                    if (r == 0)
                    {
                        break;
                    }
                    string str = Encoding.UTF8.GetString(buffer, 0, r);
                    Invoke(new Action(() => {//在线程里修改界面
                        showMsg(socketSend.RemoteEndPoint + ":" + str);
                    }));
                }
            }
            catch
            {            }
        }
        void showMsg(string str)
        {
            textBox1.AppendText(str + "\r\n");
        }
        //服务器给客户端发送消息

        private void button2_Click_1(object sender, EventArgs e)
        {
            string str = textBox2.Text;
            Console.WriteLine(str);
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(str);
            socketSend.Send(buffer);
        }
    }
}


```
结果：
![在这里插入图片描述](https://img-blog.csdnimg.cn/ac9e547890934a80b03824a92c8dcf75.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
## 四、单线程端口扫描器

```csharp
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Port_scan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //自定义变量
        private int port;//记录当前扫描的端口号
        private string Address;//记录扫描的系统地址
        private bool[] done = new bool[65536];//记录端口的开放状态
        private int start;//记录扫描的起始端口
        private int end;//记录扫描的结束端口
        private bool OK;

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = textBox2.Text;
            label6.Text = textBox3.Text;
            progressBar1.Minimum = Int32.Parse(textBox2.Text);
            progressBar1.Maximum = Int32.Parse(textBox3.Text);
            listBox1.Items.Clear();
            listBox1.Items.Add("端口扫描器v1.0.");
            listBox1.Items.Add("");
            PortScan();
        }
        private void PortScan()
        {
            start = Int32.Parse(textBox2.Text);
            end = Int32.Parse(textBox3.Text);
            //判断输入端口是否合法
            if ((start >= 0 && start <= 65536) && (end >= 0 && end <= 65536) && (start <= end))
            {
                listBox1.Items.Add("开始扫描：这个过程可能需要等待几分钟！");
                Address = textBox1.Text;
                for (int i = start; i <= end; i++)
                {
                    port = i;
                    Scan();
                    progressBar1.Value = i;
                    label5.Text = i.ToString();
                }
                while (!OK)
                {
                    OK = true;
                    for (int i = start; i <= end; i++)
                    {
                        if (!done[i])
                        {
                            OK = false;
                            break;
                        }
                    }
                }
                listBox1.Items.Add("扫描结束！");
            }
            else
            {
                MessageBox.Show("输入错误，端口范围为[0,65536]");
            }
        }
        //连接端口
        private void Scan()
        {
            int portnow = port;
            done[portnow] = true;
            TcpClient objTCP = null;
            try
            {
                objTCP = new TcpClient(Address, portnow);
                listBox1.Items.Add("端口" + portnow.ToString() + "开放");
            }
            catch
            {

            }

        }
    }
}


```
![在这里插入图片描述](https://img-blog.csdnimg.cn/85b2e59e66af46f5a6984a9325317ecb.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)

![在这里插入图片描述](https://img-blog.csdnimg.cn/1a92ce4432264764967c34eab67d8830.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)



## 五、多线程端口扫描器

```csharp
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muti_thread_port_scan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //自定义变量
        private int port;//记录当前扫描的端口号
        private string Address;//记录扫描的系统地址
        private bool[] done = new bool[65536];//记录端口是否已经扫描
        private int start;//记录扫描的起始端口
        private int end;//记录扫描的结束端口
        private bool OK;
        private Thread scanThread;  
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void label4_TextChanged(object sender, EventArgs e)
        {
            label4.Text = textBox2.Text;//设定进度条的起始端口
        }
        private void label6_TextChanged(object sender, EventArgs e)
        {
            label6.Text = textBox3.Text;//设置进度条的终止端口
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4_TextChanged(sender, e);
            label6_TextChanged(sender, e);
            //创建线程
            Thread procss = new Thread(new ThreadStart(PortScan));
            procss.Start();
            //设定进度条的范围
            progressBar1.Minimum = Int32.Parse(textBox2.Text);
            progressBar1.Maximum = Int32.Parse(textBox3.Text);
            //显示框的初始化
            listBox1.Items.Clear();
            listBox1.Items.Add("端口扫描器 v1.0");
            listBox1.Items.Add(" ");
        }
        private void PortScan()
        {
            start = Int32.Parse(textBox2.Text);
            end = Int32.Parse(textBox3.Text);
            //检查端口的合法性
            if ((start >= 0 && start <= 65536) && (end >= 0 && end <= 65536) && (start <= end))
            {
                
                Invoke(new Action(() => {//在线程里修改界面
                    listBox1.Items.Add("开始扫描：这个过程可能需要等待几分钟！");
                }));
                Address = textBox1.Text;
                for (int i = start; i <= end; i++)
                {
                    port = i;
                    //对该端口进行扫描的线程
                    scanThread = new Thread(Scan);
                    scanThread.Start();
                    //使线程睡眠
                    System.Threading.Thread.Sleep(100);
                    
                    Invoke(new Action(() => {//在线程里修改界面
                        progressBar1.Value = i;
                        label5.Text = i.ToString();
                    }));   
                }
                //未完成时情况
                while (!OK)
                {
                    OK = true;
                    for (int i = start; i <= end; i++)
                    {
                        if (!done[i])
                        {
                            OK = false;
                            break;
                        }
                    }
                }
               
                Invoke(new Action(() => {//在线程里修改界面
                    listBox1.Items.Add("扫描结束！");
                }));
                System.Threading.Thread.Sleep(1000);
            }
            else
            {
                Invoke(new Action(() => {//在线程里修改界面
                    MessageBox.Show("输入错误，端口范围为[0,65536]");
                }));
                
            }
        }
        private void Scan()
        {
            int portnow = port;
            //创建线程变量
            Thread Threadnow = scanThread;
            done[portnow] = true;
            //创建TcpClient对象，TcpClient用于TCP网络服务提供客户端连接
            TcpClient objTCP = null;
            //扫描端口，成功就写入信息
            try
            {
                objTCP = new TcpClient(Address, portnow);
                Invoke(new Action(() => {//在线程里修改界面
                    listBox1.Items.Add("端口" + portnow.ToString() + "开放！");
                }));
                objTCP.Close();
            }
            catch
            {

            }
        }


    }
}


```
![在这里插入图片描述](https://img-blog.csdnimg.cn/aefa94cb0c22437cb3a335c042f59850.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
![在这里插入图片描述](https://img-blog.csdnimg.cn/c580763839a146219be72c92bf462456.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
![在这里插入图片描述](https://img-blog.csdnimg.cn/60ef3888ae5f47db881ff30aa56ed5ba.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA6Zqo5b-Dzr7miYDmrLI=,size_20,color_FFFFFF,t_70,g_se,x_16)
参考：
https://blog.csdn.net/junseven164/article/details/121469255?spm=1001.2014.3001.5501
